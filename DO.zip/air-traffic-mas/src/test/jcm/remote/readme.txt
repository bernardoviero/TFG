This JaCaMo application illustrates the creation of remote workspaces
from the JCM file.

We have two options to run this project:

1) using jacamo scripts (if installed)

    jacamo remote.jcm --deploy-hosts smart_home.properties

2) using gradle

    gradle

   in this case, see build.gradle for details and parameters
