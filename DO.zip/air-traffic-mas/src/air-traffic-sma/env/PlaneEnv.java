import jason.asSyntax.*;
import jason.environment.*;
import java.util.logging.*;

public class PlaneEnv extends Environment {
    private Logger logger = Logger.getLogger("plane_landing.mas2j."+PlaneEnv.class.getName());

    @Override
    public boolean executeAction(String agName, Structure action) {
        if (action.getFunctor().equals("check_fuel")) {
            Literal fuelLevel = Literal.parseLiteral("fuel(50)");
            addPercept(agName, fuelLevel);
        }
        return true;
    }

    @Override
    public void stop() {
        super.stop();
    }
}