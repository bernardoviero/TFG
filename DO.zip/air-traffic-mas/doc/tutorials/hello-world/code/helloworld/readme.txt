To run the application, execute the script gradlew:
  ./gradlew

To run the version with a better "display":
  ./gradlew grid

In the case of the distributed MAS, the application at host 'europe' can be run with:
  ./gradlew europe

and application at host 'america' with:
  ./gradlew america
