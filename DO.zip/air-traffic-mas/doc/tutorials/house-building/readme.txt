The folder src/examples/house-building is to be given to students as the
initial solution.

This folder contains the material for tutors, including tips for the
solution of some exercises (see also solution.html)

How to use:

1. using the slides, explain the scenario

2. open the code of the AuctionArt and explain

3. open the code of giacomo and explain the phase 1

4. explain one company (A)

5. run and show what to see
   - console
   - mind inspector (how obs prop are included there, the annotations)
     usually at http://localhost:3272

6. exercises (see solutions.html)
   - describe
   - give some time
   - show/run the solution
   - comment on alternatives

(Org Part)

7. specify the org with the students

8. explain the XML file for the OS

9. explain how agents interact
   - how giacomo creates org arts
   - org actions like adoptRole

   - reaction to org bels like
     +obligation

10. run and show the GUI of artifacts
    who GUI at http://localhost:3271

11. exercises
