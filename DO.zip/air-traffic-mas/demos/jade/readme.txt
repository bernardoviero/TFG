Steps to run this demo:

1. run the jade main container with agent Alice

    ./gradlew run_mc

2. run an ordinary jade container with agent Bob

    ./gradlew run_bc

3. run agent Carlos coded in Java/Jade (not .asl)

    ./gradlew run_cc

the code of Carlos is at src/java/jadeag/Carlos.java
