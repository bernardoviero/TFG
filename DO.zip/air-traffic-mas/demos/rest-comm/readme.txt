This demo illustrates how to run distributed agents using JaCaMo-REST for their communication.

Steps to run this demo:

1. run the mas at host h1

    ./gradlew run_h1

2. run the mas at host h2

    ./gradlew run_h2

Alice output:

[alice] Counter is 10
[alice] Hello form bob

Bob output:

[bob] Hello form alice
