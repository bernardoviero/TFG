This example is explained in the tutorial

http://jacamo-lang.github.io/jacamo/tutorials/coordination/readme.html
